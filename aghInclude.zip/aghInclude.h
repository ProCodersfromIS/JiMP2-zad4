#ifndef AGHINCLUDE_H
#define AGHINCLUDE_H
// ------------------------------

#include <iostream>
// ------------------------------

using namespace std;
// ------------------------------

#include "aghException.h"
#include "aghContainer.h"
#include "aghVector.h"
// -------------------------------

#endif